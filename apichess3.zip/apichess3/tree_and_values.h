#ifndef TREE_AND_VALUES_H_
#define TREE_AND_VALUES_H_

int getValue(struct chessBoard *board, int color);
int* createNode(struct chessBoard *board);

#endif
